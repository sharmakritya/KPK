<html>
<head>
<link href="css/edit.css" type="text/css" rel="stylesheet"/>
</head>
<body>
<div id="left">
<img id="bar_logo" src="images/logo.jpg"/>
<br>

<a href="invites.php">Invites</a>
<br>
<a href="feedback.php" >Feedback</a>
<br>
<a href="edit.php">Edit</a>
</div>
<div id="right">

</div>
</body>
</html>