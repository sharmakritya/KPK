<html>
<head>
<link href="css/newedit.css" type="text/css" rel="stylesheet" />
</head>
<body>
<form method="post" action="">
        <table border="1px">
        	<tr>
            <td><label for="Type">Event Type:</label></td>
            <td><input type="text" name="Type" id="Type" required/></td>
            </tr>
          	<tr>
            <td><label for="Name">Name:</label></td>
            <td><input type="text" name="Name" id="Name" required/></td>
            </tr>
             <tr>
            <td><label for="description">Description:</label></td>
            <td><input type="email" name="description" id="description" required/></td>
            </tr>
            <tr>
            <td><label for="date">Date:</label></td>
            <td><input type="text" name="date" id="date" required/></td>
            </tr>
        </table>
        <br>
        	<input type="submit" value="Done"/>
        </form>
</body>
</html>