<html>
<head>
<link href="css/event_manage.css" type="text/css" rel="stylesheet"/>
</head>
<body>
<div id="left">
<br>
<a href="invites.php">Invites</a>
<br>
<a href="feedback.php">Feedback</a>
<br>
<a href="edit.php">Edit</a>
</div>
<div id="right">
<img src="images/logo.jpg" style="width:100%;height:100%"/>
</div>
</body>
</html>